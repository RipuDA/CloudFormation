'use strict';
const AWS = require('../lib/node_modules/aws-sdk');
const _archiver = require('../lib/node_modules/archiver');

var _bucket;
var _keys;

var _region;



var s3;

var funObj;

const streamTo = (_bucket, _key) => {
var stream = require('stream');
var _pass = new stream.PassThrough();
s3.upload( { Bucket: _bucket, Key: _key, Body: _pass }, (_err, _data) => { if(_err){
            console.log(_err, _err.stack);
        }
        else {
            console.log('S3 Upload is successful');
        } } );
return _pass;
};
   


module.exports={
downLoadS3File: function(awsObject,s3Object,bucketName,fileList,region,_req, _ctx, _cb)

{
    _bucket=bucketName;
    _keys=fileList;
    _region=region;
    s3=s3Object;
    
 
 funObj(awsObject,s3Object,bucketName,fileList,region,_req, _ctx, _cb);
 _cb(null, {} ); 
 

}
}


funObj = async(awsObject,s3Object,bucketName,fileList,region,_req, _ctx, _cb) => 
{


  
console.log('inside');

 var _list = await Promise.all(_keys.map(_key => new Promise((_resolve, _reject) => {
                console.log(_bucket,_key);
                const params = {
                    Bucket: _bucket,
                    Key: _key
                };
                s3Object.getObject(params).promise().then(_data => _resolve( { data: _data.Body, name: _key }));
            }
            ))).catch(_err => { throw new Error(_err) } );

    

 await new Promise((_resolve, _reject) => {
        var _myStream = streamTo(_bucket, 'filefunc01.zip'); //Now we instantiate that pipe...
        var _archive = _archiver('zip');
        console.log('Inside this block');
        _archive.on('error', err => { throw new Error(err); } );
       
        //Your promise gets resolved when the fluid stops running... so that's when you get to close and resolve
        _myStream.on('close', _resolve);
        _myStream.on('end', _resolve);
        _myStream.on('error', _reject);
       
        _archive.pipe(_myStream); //Pass that pipe to _archive so it can push the fluid straigh down to S3 bucket
        _list.forEach(_itm => _archive.append(_itm.data, { name: _itm.name } ) ); //And then we start adding files to it
        _archive.finalize(); //Tell is, that's all we want to add. Then when it finishes, the promise will resolve in one of those events up there
        
    }).catch(_err => { throw new Error(_err) } );


 
   

};




 









   